# Rubric Adjustment Log (English)

Use this file to document every rubric iteration until the TOTAL score matches across:
Human, Model1, Model2, Model3.

## Iteration v1 (initial)
- Date:
- Changes made:
- Why the change was needed:
- What disagreement it fixed (Human vs Model1/2/3):

## Iteration v2
- Date:
- Changes made:
- Why the change was needed:
- What disagreement it fixed:

## Iteration v3
- Date:
- Changes made:
- Why the change was needed:
- What disagreement it fixed:
