# Submission Checklist

Package the following into ONE zip and upload as a link:

1) Your final Prompt+Rubric JSON file (English)
   - Use one of the JSONs in this folder as a starting point.
   - Make sure `total_points` matches the sum of all rubric items.

2) Your scoring records for EACH iteration
   - Include Human / Model1 / Model2 / Model3 scores.
   - Ensure the TOTAL score is identical across all four.

3) Your adjustment path
   - Include `adjustment_log.md` showing how/why you revised the rubric each time.

4) The code produced by the LLM when executing the task prompt
   - Include the model's final patch/output (changed files).
   - If you ran commands/tests, include logs/screenshots as needed.

Notes:
- All rubric text must be in English.
- Avoid vague criteria; each item must be objectively verifiable.
