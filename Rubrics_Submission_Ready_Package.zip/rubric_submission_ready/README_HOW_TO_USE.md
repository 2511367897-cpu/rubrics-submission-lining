# How to use this package

This folder contains two ready-to-use *English* rubric JSONs derived from the prompts in:
`Prompt_Rubric试标题目sample_5_l2 - 副本.json`.

## Which one should I use?
- If your exam task is the OSRSTracker weather prompt: use `Prompt_Rubric_OSRSTracker_weather.json`
- If you are practicing with the demo Anti-Tic-Tac-Toe Java task: use `Prompt_Rubric_AntiTicTacToe_4win_3lose.json`

## Scoring workflow (required)
1. Run the task prompt on the given repo with:
   - Human execution + Human scoring
   - Model1 scoring
   - Model2 scoring
   - Model3 scoring
2. Fill `scoring_sheet_template.csv`
3. If the TOTAL score differs across Human/Model1/2/3:
   - revise the rubric text to remove ambiguity
   - log changes in `adjustment_log.md`
   - repeat until totals match

## Output language
- Rubric text must be in English.
